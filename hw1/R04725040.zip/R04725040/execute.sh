python3 hw1.py $@
